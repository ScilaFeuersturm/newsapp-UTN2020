import React, { useContext } from "react";
import { useHistory } from "react-router-dom";
import { isAuthenticated, logout } from "../../services/users";
import Navbar from "../../_components/Navbar/Navbar";
import Footer from "../../_components/Footer/Footer"

export function Layout({ props, children }) {
  const history = useHistory();
  const handleLogout = () => {
    logout();
    history.push("/login");
  };
  //No renderiza cuando se le agregan navbar y footer
  //Tampoco sin ellos, consultar

  return (
    <div>
      <div>
      {isAuthenticated() && <button onClick={handleLogout}>Salir</button>}
      {children}
      </div>
    </div>
  );
}
