import React, { useState } from "react";
import { Link, useHistory } from 'react-router-dom';
import NavigationBar from '../../_components/Navbar/Navbar'
import "../Login/Login.css"
import { login } from '../../services/users';
import Footer from '../../_components/Footer/Footer'


const Login= () => {
  const history = useHistory();
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const response = await login(email, password);
    if(response.status) {
      history.push('/news');
      console.log(response.status)
    }else{
      console.log(response.status)
    }
  }
  

  const handleChange = (event) => {
    setEmail(event.target.value);
    if(event.target.value.length < 4) {
      setEmailError('El mail debe tener minimo de 4 letras');
    } else {
      setEmailError('');
    }
  }
  /* Diseño : Ver el margen, está quedando muy pegado al navbar */

    return (
      <div>
        <NavigationBar></NavigationBar>
      <div className="Login">
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Email</label>
            <input input className={emailError ? 'invalid' : ''} type="email" value={email} onChange={handleChange} placeholder="Email" ></input>
            <span>{emailError}</span>
          </div>
          <div className="form-group">
            <label>Password</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" ></input>
          </div>
          <div className="form-group">
            <input type="checkbox"></input>
            <label className="form-check-label">Recordar Usuario</label>
          </div>
          <button className="btn btn-primary">Login</button>
          <Link to="/register" className="btn btn-primary">Register</Link>
        </form>
      </div>
      <Footer></Footer>
      </div>
    );
  }

export default Login;