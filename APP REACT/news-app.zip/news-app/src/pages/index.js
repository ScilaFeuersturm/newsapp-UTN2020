export {default as Contact} from "./Contact/Contact";
export { default as HomePage } from "./HomePage/HomePage";
export { default as Login } from "./Login/Login";
export {default as News } from "./News/News";
export { default as NotFound } from "./NotFound/NotFound";
export { default as Register } from "./Register/Register";
