import React, { Fragment, useEffect, useState } from "react";
import "../News/News.css";
import Loader from '../../_components/Loader/Loader'
import {getNews, getNewsList} from '../../services/Services';
import NewsItem from "../../_components/NewsItem/NewsItem";


/* La edición se puede manejar en la misma página o es necesario crear una página diferente para la gestion de las mismas? */
const News = ({ header, history }) => {
  const [news, setNews] = useState([]);
  const [isLoading, setIsLoading] = useState(true);


  const getNewsList = async () => {
    const response = await getNewsList();
    if (response.status) {
      setNews(response.data);
      console.log(response.data);

    }
    else {
      console.log("Setear error")
      /*Crear un nuevo componente con una leyenda: "No se pueden mostrar noticias en este momento, intente más tarde" */
    }
  };

  useEffect(() => {
    getNewsList();
  }, []);

  /*const handleReload = () => {
    setIsLoading(true);
    getNewsList();
  };
  
  Primero probar que vengan bien los primeros datos*/

  return (
    <Fragment>
      <ul className="list">
        {news.map((news) => (
          <NewsItem imagen={news.image}  title={news.title} subtitle={news.subtitle} body ={news.body}/>
        ))}
      </ul>
    </Fragment>
  );
  }

export default News;